// HEADER

var menusvg = document.querySelector('.menuburger');
var menuburger = document.querySelector('.menuburger-div');
var svg = document.querySelector('#svgmenu');
var activemenup = document.querySelector('.activemenusvg');

var revues = document.querySelectorAll('.revues');
var recherche = document.querySelectorAll('.recherche');
var newsletter = document.querySelector('.newsletter');
var footer = document.querySelectorAll('#mobile_footer');
var touteActu = document.querySelector('#toutes-actualites');
var mainIndex = document.querySelector('.main-index');


menusvg.addEventListener('click', function() {
  for (var i = 0; i < revues.length; i++) {
    revues[i].classList.toggle('hide');
  };
  for (var j = 0; j < recherche.length; j++) {
    recherche[j].classList.toggle('hide');
  };
  for (var h = 0; h < footer.length; h++) {
    footer[h].classList.toggle('hide');
  };
  menuburger.classList.toggle('show');
  svg.classList.toggle('header-active');
  activemenup.classList.toggle('header-active');
  newsletter.classList.toggle('hide');
  touteActu.classList.toggle('hide');
  mainIndex.classList.toggle('hide');
});
